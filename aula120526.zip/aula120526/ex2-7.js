let vetor = [5,3,78,3,2,564,64,5]
let control = vetor.length
function soma(){
    let res = 0
    for(let i = 0; i< control ;i++){
        res = res + vetor[i]
        if (i == control-1){
            return res
        }
    }
    
}
console.log(soma());
