let pt = [85, 12, 45, 150, 22]
let best = 0;
function melhorPt() {
    for (let i = 0; i < pt.length; i++) {
        best = Math.max(best, pt[i])
    }
    return best
}
console.log(melhorPt())
