let alunos = ['dora', 'naruto uzocrack', 'shadow', 'joaozinho gameplays']
let notas = [8, 6, 9, 2]
function notasAlu() {
    for (let i = 0; i < alunos.length; i++) {
        if (notas[i] >= 7) {
            console.log(alunos[i], "aprovado");
        }
        else if (notas[i] < 7 && notas[i] >= 5) {
            console.log(alunos[i], "recuperação");
        }
        else {
            console.log(alunos[i], "reprovado");

        }
    }
}
notasAlu()