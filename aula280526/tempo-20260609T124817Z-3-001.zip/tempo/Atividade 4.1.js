const agenta = [{
    titulo: "Reunião",
    data: "2026-06-10",
    hora: "14:00"
}]
agenta.push({ teste: "teste", data: "2026-06-08", hora: "14:00" })
for (let pass = 0; pass < agenta.length - 1; pass++) {
  for (let i = 0; i < agenta.length - 1 - pass; i++) {
    if (agenta[i].data > agenta[i + 1].data) {
      const temp = agenta[i];
      agenta[i] = agenta[i + 1];
      agenta[i + 1] = temp;
    }
  }
}

console.log(agenta);