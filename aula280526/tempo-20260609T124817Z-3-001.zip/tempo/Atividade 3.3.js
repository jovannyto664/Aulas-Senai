const futuro = new Date("2026-07-30")
let calculo = futuro - new Date();
if (calculo <= 0) {
    console.log("data ja passou");
} else {
    const dias = Math.floor(calculo / (1000 * 60 * 60 * 24))
    calculo %= (1000 * 60 * 60 * 24)
    const horas = Math.floor(calculo / (1000 * 60 * 60))
    calculo %= (1000 * 60 * 60)
    const minutos = Math.floor(calculo / (1000 * 60))
    calculo %= (1000 * 60)
    const segundos = Math.floor(calculo / 1000)
    console.log(`${dias} dias, ${horas} horas, ${minutos} minutos, ${segundos} segundos`);
}







/*console.log(calculo);
calculo = calculo / (1000 * 60 * 60 * 24);
calculo = new Date(calculo);
const formatada = calculo.toLocaleString("pt-BR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit"
});
console.log(formatada);*/






/*console.log(calculo.toLocaleString("pt-BR",{
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    secund: "2-digit"
}));*/

