function verificarVencimento(datavencimento) {
    let venc = new Date(datavencimento)
    if (new Date() > venc) {
        console.log("Vencido");
    } else {
        console.log("Dentro do prazo");
    }
}
verificarVencimento("2025-12-01")