let contador = 0
const contando = setInterval(() => {
    contador++;
    console.log(contador);
    if (contador === 10) {
        clearInterval(contando);
    }
}, 1000);

/*
let contador = 0
let contando = setInterval((n)=>{n=contador+1,contador=n, console.log(n)},1000)
if (contador ==11){clearInterval(contando)}*/