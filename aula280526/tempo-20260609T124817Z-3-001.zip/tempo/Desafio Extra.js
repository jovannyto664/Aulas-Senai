function formatarData(data) {
  const dataObj = new Date(data);

  const formatada = dataObj.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  console.log(formatada);
}

formatarData("2026-05-27");