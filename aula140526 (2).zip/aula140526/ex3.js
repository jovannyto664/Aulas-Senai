const personagem = {
nome: "carlinhos",
vida: 2000,
energia: 500,
nivel: 675,
ouro:43278146986,
atacar(){
    this.energia -=15
},
treinar(){
    
},

}